# Database migrations

EF Core migrations for Identity and PocketPilot domain models belong here. `AddPocketPilotDomainEntities` adopts the pre-existing LocalDB feature tables, adds the Achievement requirement column, aligns contribution ownership, adds indexes and restrictive foreign keys, and creates missing feature tables for a fresh database. Its automatic `Down` is intentionally disabled to avoid deleting student financial history.
