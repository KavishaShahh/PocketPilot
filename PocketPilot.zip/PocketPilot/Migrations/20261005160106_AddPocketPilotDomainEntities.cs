using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PocketPilot.Migrations;

public partial class AddPocketPilotDomainEntities : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"
IF OBJECT_ID(N'dbo.Budgets', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Categories (
        CategoryId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
        Name nvarchar(50) NOT NULL,
        Icon nvarchar(50) NOT NULL,
        ColorCode nvarchar(20) NOT NULL,
        Description nvarchar(200) NULL,
        IsDefault bit NOT NULL,
        UserId nvarchar(450) NULL,
        CONSTRAINT FK_Categories_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.Achievements (
        AchievementId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Achievements PRIMARY KEY,
        Code nvarchar(50) NOT NULL,
        Title nvarchar(100) NOT NULL,
        Description nvarchar(300) NOT NULL,
        BadgeIcon nvarchar(50) NOT NULL,
        ColorClass nvarchar(30) NOT NULL,
        Requirement nvarchar(300) NOT NULL CONSTRAINT DF_Achievements_Requirement DEFAULT(N'')
    );
    CREATE TABLE dbo.Challenges (
        ChallengeId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Challenges PRIMARY KEY,
        Title nvarchar(100) NOT NULL,
        Description nvarchar(500) NOT NULL,
        DurationDays int NOT NULL,
        TargetSaving decimal(18,2) NULL,
        CategoryConstraint nvarchar(50) NULL,
        BadgeReward nvarchar(100) NOT NULL,
        Difficulty nvarchar(20) NOT NULL,
        Icon nvarchar(50) NOT NULL,
        IsActive bit NOT NULL
    );
    CREATE TABLE dbo.Budgets (
        BudgetId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Budgets PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        BudgetMonth int NOT NULL,
        BudgetYear int NOT NULL,
        TotalBudget decimal(18,2) NOT NULL,
        FoodBudget decimal(18,2) NOT NULL,
        TravelBudget decimal(18,2) NOT NULL,
        StudyBudget decimal(18,2) NOT NULL,
        EntertainmentBudget decimal(18,2) NOT NULL,
        ShoppingBudget decimal(18,2) NOT NULL,
        EmergencyBudget decimal(18,2) NOT NULL,
        OtherBudget decimal(18,2) NOT NULL,
        CreatedDate datetime2 NOT NULL,
        UpdatedDate datetime2 NULL,
        CONSTRAINT FK_Budgets_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.BudgetAlerts (
        AlertId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_BudgetAlerts PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        Title nvarchar(100) NOT NULL,
        Message nvarchar(500) NOT NULL,
        Severity nvarchar(20) NOT NULL,
        Category nvarchar(50) NULL,
        CreatedDate datetime2 NOT NULL,
        IsDismissed bit NOT NULL,
        CONSTRAINT FK_BudgetAlerts_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.SavingsGoals (
        GoalId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SavingsGoals PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        GoalName nvarchar(100) NOT NULL,
        Description nvarchar(300) NULL,
        TargetAmount decimal(18,2) NOT NULL,
        CurrentSavedAmount decimal(18,2) NOT NULL,
        TargetDate datetime2 NOT NULL,
        Priority nvarchar(20) NOT NULL,
        Status nvarchar(20) NOT NULL,
        CreatedDate datetime2 NOT NULL,
        CONSTRAINT FK_SavingsGoals_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.Expenses (
        ExpenseId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Expenses PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        Amount decimal(18,2) NOT NULL,
        CategoryId int NOT NULL,
        Description nvarchar(100) NOT NULL,
        ExpenseDate datetime2 NOT NULL,
        PaymentMethod nvarchar(50) NOT NULL,
        Notes nvarchar(500) NULL,
        CreatedDate datetime2 NOT NULL,
        CONSTRAINT FK_Expenses_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION,
        CONSTRAINT FK_Expenses_Categories_CategoryId FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(CategoryId) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.SavingsContributions (
        ContributionId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SavingsContributions PRIMARY KEY,
        SavingsGoalId int NOT NULL,
        UserId nvarchar(450) NOT NULL,
        Amount decimal(18,2) NOT NULL,
        ContributionDate datetime2 NOT NULL,
        Notes nvarchar(300) NULL,
        CreatedDate datetime2 NOT NULL,
        CONSTRAINT FK_SavingsContributions_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION,
        CONSTRAINT FK_SavingsContributions_SavingsGoals_SavingsGoalId FOREIGN KEY (SavingsGoalId) REFERENCES dbo.SavingsGoals(GoalId) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.UserChallenges (
        UserChallengeId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_UserChallenges PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        ChallengeId int NOT NULL,
        StartDate datetime2 NOT NULL,
        EndDate datetime2 NOT NULL,
        ProgressPercentage int NOT NULL,
        Status nvarchar(20) NOT NULL,
        Notes nvarchar(300) NULL,
        CreatedDate datetime2 NOT NULL,
        CONSTRAINT FK_UserChallenges_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION,
        CONSTRAINT FK_UserChallenges_Challenges_ChallengeId FOREIGN KEY (ChallengeId) REFERENCES dbo.Challenges(ChallengeId) ON DELETE NO ACTION
    );
    CREATE TABLE dbo.UserAchievements (
        UserAchievementId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_UserAchievements PRIMARY KEY,
        UserId nvarchar(450) NOT NULL,
        AchievementId int NOT NULL,
        EarnedDate datetime2 NOT NULL,
        CONSTRAINT FK_UserAchievements_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION,
        CONSTRAINT FK_UserAchievements_Achievements_AchievementId FOREIGN KEY (AchievementId) REFERENCES dbo.Achievements(AchievementId) ON DELETE NO ACTION
    );
END
ELSE
BEGIN
    IF OBJECT_ID(N'dbo.Categories', N'U') IS NULL OR OBJECT_ID(N'dbo.Achievements', N'U') IS NULL
       OR OBJECT_ID(N'dbo.Challenges', N'U') IS NULL OR OBJECT_ID(N'dbo.BudgetAlerts', N'U') IS NULL
       OR OBJECT_ID(N'dbo.Expenses', N'U') IS NULL OR OBJECT_ID(N'dbo.SavingsGoals', N'U') IS NULL
       OR OBJECT_ID(N'dbo.SavingsContributions', N'U') IS NULL OR OBJECT_ID(N'dbo.UserChallenges', N'U') IS NULL
       OR OBJECT_ID(N'dbo.UserAchievements', N'U') IS NULL
    BEGIN
        THROW 51001, 'PocketPilot feature schema is only partially present; migration stopped without dropping existing data.', 1;
    END;

    IF COL_LENGTH(N'dbo.Achievements', N'Requirement') IS NULL
        ALTER TABLE dbo.Achievements ADD Requirement nvarchar(300) NOT NULL CONSTRAINT DF_Achievements_Requirement DEFAULT(N'');

    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.SavingsContributions') AND name = N'UserId' AND max_length = -1)
        ALTER TABLE dbo.SavingsContributions ALTER COLUMN UserId nvarchar(450) NOT NULL;
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AspNetUsers') AND name = N'IX_AspNetUsers_DefaultExpenseCategoryId')
    CREATE INDEX IX_AspNetUsers_DefaultExpenseCategoryId ON dbo.AspNetUsers(DefaultExpenseCategoryId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Achievements') AND name = N'IX_Achievements_Code')
    CREATE UNIQUE INDEX IX_Achievements_Code ON dbo.Achievements(Code);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.BudgetAlerts') AND name = N'IX_BudgetAlerts_UserId_IsDismissed_CreatedDate')
    CREATE INDEX IX_BudgetAlerts_UserId_IsDismissed_CreatedDate ON dbo.BudgetAlerts(UserId, IsDismissed, CreatedDate);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Budgets') AND name = N'IX_Budgets_UserId_BudgetMonth_BudgetYear')
    CREATE UNIQUE INDEX IX_Budgets_UserId_BudgetMonth_BudgetYear ON dbo.Budgets(UserId, BudgetMonth, BudgetYear);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Budgets') AND name = N'IX_Budgets_UserId_BudgetYear_BudgetMonth')
    CREATE INDEX IX_Budgets_UserId_BudgetYear_BudgetMonth ON dbo.Budgets(UserId, BudgetYear, BudgetMonth);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Categories') AND name = N'IX_Categories_UserId')
    CREATE INDEX IX_Categories_UserId ON dbo.Categories(UserId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Expenses') AND name = N'IX_Expenses_CategoryId')
    CREATE INDEX IX_Expenses_CategoryId ON dbo.Expenses(CategoryId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Expenses') AND name = N'IX_Expenses_UserId_ExpenseDate')
    CREATE INDEX IX_Expenses_UserId_ExpenseDate ON dbo.Expenses(UserId, ExpenseDate);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SavingsContributions') AND name = N'IX_SavingsContributions_SavingsGoalId')
    CREATE INDEX IX_SavingsContributions_SavingsGoalId ON dbo.SavingsContributions(SavingsGoalId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SavingsContributions') AND name = N'IX_SavingsContributions_UserId_ContributionDate')
    CREATE INDEX IX_SavingsContributions_UserId_ContributionDate ON dbo.SavingsContributions(UserId, ContributionDate);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SavingsGoals') AND name = N'IX_SavingsGoals_UserId')
    CREATE INDEX IX_SavingsGoals_UserId ON dbo.SavingsGoals(UserId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.UserAchievements') AND name = N'IX_UserAchievements_AchievementId')
    CREATE INDEX IX_UserAchievements_AchievementId ON dbo.UserAchievements(AchievementId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.UserAchievements') AND name = N'IX_UserAchievements_UserId_AchievementId')
    CREATE UNIQUE INDEX IX_UserAchievements_UserId_AchievementId ON dbo.UserAchievements(UserId, AchievementId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.UserChallenges') AND name = N'IX_UserChallenges_ChallengeId')
    CREATE INDEX IX_UserChallenges_ChallengeId ON dbo.UserChallenges(ChallengeId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.UserChallenges') AND name = N'IX_UserChallenges_UserId')
    CREATE INDEX IX_UserChallenges_UserId ON dbo.UserChallenges(UserId);

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_BudgetAlerts_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.BudgetAlerts DROP CONSTRAINT FK_BudgetAlerts_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_BudgetAlerts_AspNetUsers_UserId')
    ALTER TABLE dbo.BudgetAlerts WITH CHECK ADD CONSTRAINT FK_BudgetAlerts_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Budgets_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.Budgets DROP CONSTRAINT FK_Budgets_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Budgets_AspNetUsers_UserId')
    ALTER TABLE dbo.Budgets WITH CHECK ADD CONSTRAINT FK_Budgets_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Categories_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.Categories DROP CONSTRAINT FK_Categories_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Categories_AspNetUsers_UserId')
    ALTER TABLE dbo.Categories WITH CHECK ADD CONSTRAINT FK_Categories_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Expenses_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.Expenses DROP CONSTRAINT FK_Expenses_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Expenses_AspNetUsers_UserId')
    ALTER TABLE dbo.Expenses WITH CHECK ADD CONSTRAINT FK_Expenses_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Expenses_Categories_CategoryId')
    ALTER TABLE dbo.Expenses WITH CHECK ADD CONSTRAINT FK_Expenses_Categories_CategoryId FOREIGN KEY(CategoryId) REFERENCES dbo.Categories(CategoryId) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SavingsGoals_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.SavingsGoals DROP CONSTRAINT FK_SavingsGoals_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SavingsGoals_AspNetUsers_UserId')
    ALTER TABLE dbo.SavingsGoals WITH CHECK ADD CONSTRAINT FK_SavingsGoals_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SavingsContributions_SavingsGoals_SavingsGoalId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.SavingsContributions DROP CONSTRAINT FK_SavingsContributions_SavingsGoals_SavingsGoalId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SavingsContributions_SavingsGoals_SavingsGoalId')
    ALTER TABLE dbo.SavingsContributions WITH CHECK ADD CONSTRAINT FK_SavingsContributions_SavingsGoals_SavingsGoalId FOREIGN KEY(SavingsGoalId) REFERENCES dbo.SavingsGoals(GoalId) ON DELETE NO ACTION;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SavingsContributions_AspNetUsers_UserId')
    ALTER TABLE dbo.SavingsContributions WITH CHECK ADD CONSTRAINT FK_SavingsContributions_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserAchievements_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.UserAchievements DROP CONSTRAINT FK_UserAchievements_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserAchievements_AspNetUsers_UserId')
    ALTER TABLE dbo.UserAchievements WITH CHECK ADD CONSTRAINT FK_UserAchievements_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserAchievements_Achievements_AchievementId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.UserAchievements DROP CONSTRAINT FK_UserAchievements_Achievements_AchievementId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserAchievements_Achievements_AchievementId')
    ALTER TABLE dbo.UserAchievements WITH CHECK ADD CONSTRAINT FK_UserAchievements_Achievements_AchievementId FOREIGN KEY(AchievementId) REFERENCES dbo.Achievements(AchievementId) ON DELETE NO ACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserChallenges_AspNetUsers_UserId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.UserChallenges DROP CONSTRAINT FK_UserChallenges_AspNetUsers_UserId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserChallenges_AspNetUsers_UserId')
    ALTER TABLE dbo.UserChallenges WITH CHECK ADD CONSTRAINT FK_UserChallenges_AspNetUsers_UserId FOREIGN KEY(UserId) REFERENCES dbo.AspNetUsers(Id) ON DELETE NO ACTION;
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserChallenges_Challenges_ChallengeId' AND delete_referential_action <> 0)
    ALTER TABLE dbo.UserChallenges DROP CONSTRAINT FK_UserChallenges_Challenges_ChallengeId;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_UserChallenges_Challenges_ChallengeId')
    ALTER TABLE dbo.UserChallenges WITH CHECK ADD CONSTRAINT FK_UserChallenges_Challenges_ChallengeId FOREIGN KEY(ChallengeId) REFERENCES dbo.Challenges(ChallengeId) ON DELETE NO ACTION;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_AspNetUsers_Categories_DefaultExpenseCategoryId')
    ALTER TABLE dbo.AspNetUsers WITH CHECK ADD CONSTRAINT FK_AspNetUsers_Categories_DefaultExpenseCategoryId FOREIGN KEY(DefaultExpenseCategoryId) REFERENCES dbo.Categories(CategoryId) ON DELETE NO ACTION;
");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        throw new NotSupportedException("PocketPilot domain migrations are non-destructive and cannot be rolled back automatically.");
    }
}
