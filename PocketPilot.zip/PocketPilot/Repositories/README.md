Data access abstractions and implementations will live in this folder as domain data is introduced.
