using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PocketPilot.Models;

namespace PocketPilot.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Budget> Budgets => Set<Budget>();
    public DbSet<Expense> Expenses => Set<Expense>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<SavingsGoal> SavingsGoals => Set<SavingsGoal>();
    public DbSet<SavingsContribution> SavingsContributions => Set<SavingsContribution>();
    public DbSet<Challenge> Challenges => Set<Challenge>();
    public DbSet<UserChallenge> UserChallenges => Set<UserChallenge>();
    public DbSet<Achievement> Achievements => Set<Achievement>();
    public DbSet<UserAchievement> UserAchievements => Set<UserAchievement>();
    public DbSet<BudgetAlert> BudgetAlerts => Set<BudgetAlert>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<ApplicationUser>(entity =>
        {
            entity.Property(user => user.Name)
                .HasColumnName("FullName")
                .HasMaxLength(100)
                .IsRequired();
            entity.Property(user => user.StudentId).HasMaxLength(50);
            entity.Property(user => user.CollegeName).HasMaxLength(150);
            entity.Property(user => user.DefaultCurrency).HasMaxLength(10).IsRequired();
            entity.Property(user => user.ProfilePicture)
                .HasColumnName("ProfilePictureUrl")
                .HasMaxLength(255);
        });
        modelBuilder.Entity<ApplicationUser>()
            .Property(user => user.MonthlyBudgetPreference)
            .HasPrecision(18, 2);

        modelBuilder.Entity<ApplicationUser>()
            .HasOne(user => user.DefaultExpenseCategory)
            .WithMany(category => category.DefaultForUsers)
            .HasForeignKey(user => user.DefaultExpenseCategoryId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Budget>(entity =>
        {
            entity.HasIndex(budget => new { budget.UserId, budget.BudgetMonth, budget.BudgetYear }).IsUnique();
            entity.HasIndex(budget => new { budget.UserId, budget.BudgetYear, budget.BudgetMonth });
            entity.Property(budget => budget.TotalBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.FoodBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.TravelBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.StudyBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.EntertainmentBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.ShoppingBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.EmergencyBudget).HasPrecision(18, 2);
            entity.Property(budget => budget.OtherBudget).HasPrecision(18, 2);
            entity.HasOne(budget => budget.User).WithMany(user => user.Budgets)
                .HasForeignKey(budget => budget.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Expense>(entity =>
        {
            entity.HasIndex(expense => new { expense.UserId, expense.ExpenseDate });
            entity.HasIndex(expense => expense.CategoryId);
            entity.Property(expense => expense.Amount).HasPrecision(18, 2);
            entity.Property(expense => expense.Description).HasMaxLength(100).IsRequired();
            entity.Property(expense => expense.PaymentMethod).HasMaxLength(50).IsRequired();
            entity.Property(expense => expense.Notes).HasMaxLength(500);
            entity.HasOne(expense => expense.User).WithMany(user => user.Expenses)
                .HasForeignKey(expense => expense.UserId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(expense => expense.Category).WithMany(category => category.Expenses)
                .HasForeignKey(expense => expense.CategoryId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasIndex(category => category.UserId);
            entity.Property(category => category.Name).HasMaxLength(50).IsRequired();
            entity.Property(category => category.Icon).HasMaxLength(50).IsRequired();
            entity.Property(category => category.ColorCode).HasMaxLength(20).IsRequired();
            entity.Property(category => category.Description).HasMaxLength(200);
            entity.HasOne(category => category.User).WithMany(user => user.Categories)
                .HasForeignKey(category => category.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SavingsGoal>(entity =>
        {
            entity.HasKey(goal => goal.GoalId);
            entity.HasIndex(goal => goal.UserId);
            entity.Property(goal => goal.GoalName).HasMaxLength(100).IsRequired();
            entity.Property(goal => goal.Description).HasMaxLength(300);
            entity.Property(goal => goal.Priority).HasMaxLength(20).IsRequired();
            entity.Property(goal => goal.Status).HasMaxLength(20).IsRequired();
            entity.Property(goal => goal.TargetAmount).HasPrecision(18, 2);
            entity.Property(goal => goal.CurrentSavedAmount).HasPrecision(18, 2);
            entity.HasOne(goal => goal.User).WithMany(user => user.SavingsGoals)
                .HasForeignKey(goal => goal.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SavingsContribution>(entity =>
        {
            entity.HasKey(contribution => contribution.ContributionId);
            entity.HasIndex(contribution => contribution.SavingsGoalId);
            entity.HasIndex(contribution => new { contribution.UserId, contribution.ContributionDate });
            entity.Property(contribution => contribution.UserId).HasMaxLength(450).IsRequired();
            entity.Property(contribution => contribution.Amount).HasPrecision(18, 2);
            entity.Property(contribution => contribution.Notes).HasMaxLength(300);
            entity.HasOne(contribution => contribution.SavingsGoal).WithMany(goal => goal.Contributions)
                .HasForeignKey(contribution => contribution.SavingsGoalId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(contribution => contribution.User).WithMany(user => user.SavingsContributions)
                .HasForeignKey(contribution => contribution.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Challenge>(entity =>
        {
            entity.Property(challenge => challenge.Name).HasColumnName("Title").HasMaxLength(100).IsRequired();
            entity.Property(challenge => challenge.Description).HasMaxLength(500).IsRequired();
            entity.Property(challenge => challenge.TargetAmount).HasColumnName("TargetSaving").HasPrecision(18, 2);
            entity.Property(challenge => challenge.CategoryConstraint).HasMaxLength(50);
            entity.Property(challenge => challenge.BadgeReward).HasMaxLength(100).IsRequired();
            entity.Property(challenge => challenge.Difficulty).HasMaxLength(20).IsRequired();
            entity.Property(challenge => challenge.Icon).HasMaxLength(50).IsRequired();
        });

        modelBuilder.Entity<UserChallenge>(entity =>
        {
            entity.HasIndex(userChallenge => userChallenge.UserId);
            entity.HasIndex(userChallenge => userChallenge.ChallengeId);
            entity.Property(userChallenge => userChallenge.Progress).HasColumnName("ProgressPercentage");
            entity.Property(userChallenge => userChallenge.Status).HasMaxLength(20).IsRequired();
            entity.Property(userChallenge => userChallenge.Notes).HasMaxLength(300);
            entity.HasOne(userChallenge => userChallenge.User).WithMany(user => user.UserChallenges)
                .HasForeignKey(userChallenge => userChallenge.UserId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(userChallenge => userChallenge.Challenge).WithMany(challenge => challenge.UserChallenges)
                .HasForeignKey(userChallenge => userChallenge.ChallengeId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Achievement>(entity =>
        {
            entity.HasIndex(achievement => achievement.Code).IsUnique();
            entity.Property(achievement => achievement.Code).HasMaxLength(50).IsRequired();
            entity.Property(achievement => achievement.Name).HasColumnName("Title").HasMaxLength(100).IsRequired();
            entity.Property(achievement => achievement.Description).HasMaxLength(300).IsRequired();
            entity.Property(achievement => achievement.Icon).HasColumnName("BadgeIcon").HasMaxLength(50).IsRequired();
            entity.Property(achievement => achievement.ColorClass).HasMaxLength(30).IsRequired();
            entity.Property(achievement => achievement.Requirement).HasMaxLength(300).IsRequired();
        });

        modelBuilder.Entity<UserAchievement>(entity =>
        {
            entity.HasIndex(userAchievement => userAchievement.AchievementId);
            entity.HasIndex(userAchievement => new { userAchievement.UserId, userAchievement.AchievementId }).IsUnique();
            entity.HasOne(userAchievement => userAchievement.User).WithMany(user => user.UserAchievements)
                .HasForeignKey(userAchievement => userAchievement.UserId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(userAchievement => userAchievement.Achievement).WithMany(achievement => achievement.UserAchievements)
                .HasForeignKey(userAchievement => userAchievement.AchievementId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<BudgetAlert>(entity =>
        {
            entity.HasIndex(alert => new { alert.UserId, alert.IsDismissed, alert.CreatedDate });
            entity.Property(alert => alert.BudgetAlertId).HasColumnName("AlertId");
            entity.Property(alert => alert.Title).HasMaxLength(100).IsRequired();
            entity.Property(alert => alert.Message).HasMaxLength(500).IsRequired();
            entity.Property(alert => alert.AlertLevel).HasColumnName("Severity").HasMaxLength(20).IsRequired();
            entity.Property(alert => alert.CategoryTag).HasColumnName("Category").HasMaxLength(50);
            entity.HasOne(alert => alert.User).WithMany(user => user.BudgetAlerts)
                .HasForeignKey(alert => alert.UserId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}
