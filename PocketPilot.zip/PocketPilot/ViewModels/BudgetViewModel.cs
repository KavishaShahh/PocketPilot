using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace PocketPilot.ViewModels;

public sealed class BudgetViewModel : IValidatableObject
{
    public int BudgetId { get; set; }

    [Range(1, 12, ErrorMessage = "Choose a valid month.")]
    [Display(Name = "Budget month")]
    public int BudgetMonth { get; set; }

    [Range(2000, 2200, ErrorMessage = "Enter a valid budget year.")]
    [Display(Name = "Budget year")]
    public int BudgetYear { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Budget cannot be negative.")]
    [Display(Name = "Total budget")]
    public decimal TotalBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Food")]
    public decimal FoodBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Travel")]
    public decimal TravelBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Study")]
    public decimal StudyBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Entertainment")]
    public decimal EntertainmentBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Shopping")]
    public decimal ShoppingBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Emergency")]
    public decimal EmergencyBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99", ErrorMessage = "Category budgets cannot be negative.")]
    [Display(Name = "Other")]
    public decimal OtherBudget { get; set; }

    public string CurrencyCode { get; set; } = "USD";

    public decimal SpentAmount { get; set; }

    public decimal AllocatedBudget => FoodBudget + TravelBudget + StudyBudget + EntertainmentBudget
        + ShoppingBudget + EmergencyBudget + OtherBudget;

    public decimal UnallocatedBudget => TotalBudget - AllocatedBudget;

    public decimal RemainingBudget => TotalBudget - SpentAmount;

    public decimal PercentageSpent => TotalBudget <= 0 ? 0 : Math.Round(SpentAmount / TotalBudget * 100m, 1);

    public decimal PercentageRemaining => TotalBudget <= 0 ? 0 : Math.Round(RemainingBudget / TotalBudget * 100m, 1);

    public string MonthName => BudgetMonth is >= 1 and <= 12
        ? CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(BudgetMonth)
        : string.Empty;

    public string CurrencySymbol => CurrencyCode.ToUpperInvariant() switch
    {
        "INR" => "₹",
        "USD" or "CAD" or "AUD" => "$",
        "EUR" => "€",
        "GBP" => "£",
        "JPY" => "¥",
        _ => CurrencyCode.ToUpperInvariant() + " "
    };

    public string FormatMoney(decimal amount) => $"{CurrencySymbol}{amount:N2}";

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (FoodBudget < 0 || TravelBudget < 0 || StudyBudget < 0 || EntertainmentBudget < 0
            || ShoppingBudget < 0 || EmergencyBudget < 0 || OtherBudget < 0)
        {
            yield return new ValidationResult(
                "Category budgets cannot be negative.",
                new[] { nameof(FoodBudget), nameof(TravelBudget), nameof(StudyBudget), nameof(EntertainmentBudget), nameof(ShoppingBudget), nameof(EmergencyBudget), nameof(OtherBudget) });
        }

        if (AllocatedBudget > TotalBudget)
        {
            yield return new ValidationResult(
                "Category allocations cannot exceed your total monthly budget.");
        }
    }
}

public sealed class BudgetIndexViewModel
{
    public string CurrencyCode { get; set; } = "USD";

    public BudgetViewModel? CurrentBudget { get; set; }

    public IReadOnlyList<BudgetViewModel> Budgets { get; set; } = Array.Empty<BudgetViewModel>();

    public IReadOnlyList<BudgetViewModel> PreviousBudgets { get; set; } = Array.Empty<BudgetViewModel>();

    public bool HasCurrentBudget => CurrentBudget is not null;
}

public enum BudgetOperationStatus
{
    Success,
    Duplicate,
    NotFound,
    NoPreviousBudget
}

public sealed record BudgetOperationResult(BudgetOperationStatus Status, int? BudgetId = null);