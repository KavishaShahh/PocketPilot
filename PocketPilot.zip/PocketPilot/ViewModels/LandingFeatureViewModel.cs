namespace PocketPilot.ViewModels;

public sealed record LandingFeatureViewModel(string Title, string Description, string IconClass);
