using System.ComponentModel.DataAnnotations;

namespace PocketPilot.ViewModels;

public sealed class ExpenseViewModel : IValidatableObject
{
    public int ExpenseId { get; set; }

    [Range(typeof(decimal), "0.01", "9999999999999999.99", ErrorMessage = "Amount must be greater than ₹0.")]
    [Display(Name = "Amount")]
    public decimal Amount { get; set; }

    [Required(ErrorMessage = "Please select an expense category.")]
    [Range(1, int.MaxValue, ErrorMessage = "Please select an expense category.")]
    [Display(Name = "Category")]
    public int? CategoryId { get; set; }

    [Required(ErrorMessage = "Please enter a valid expense description.")]
    [StringLength(100, ErrorMessage = "Description cannot exceed 100 characters.")]
    [Display(Name = "Description")]
    public string Description { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Date)]
    [Display(Name = "Expense date")]
    public DateTime ExpenseDate { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "Please select a payment method.")]
    [StringLength(50)]
    [RegularExpression("^(Cash|UPI|Debit Card|Credit Card|Bank Transfer|Other)$", ErrorMessage = "Please select a valid payment method.")]
    [Display(Name = "Payment method")]
    public string PaymentMethod { get; set; } = "Cash";

    [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters.")]
    public string? Notes { get; set; }

    public string CategoryName { get; set; } = string.Empty;
    public string CategoryIcon { get; set; } = "bi bi-tag";
    public string CategoryColor { get; set; } = "#6E5AE6";
    public string CurrencyCode { get; set; } = "USD";
    public DateTime CreatedDate { get; set; }

    public string CurrencySymbol => CurrencyCode.ToUpperInvariant() switch
    {
        "INR" => "₹",
        "USD" or "CAD" or "AUD" => "$",
        "EUR" => "€",
        "GBP" => "£",
        "JPY" => "¥",
        _ => CurrencyCode.ToUpperInvariant() + " "
    };

    public string FormatAmount(decimal amount) => $"{CurrencySymbol}{amount:N2}";

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (ExpenseDate.Date < new DateTime(2000, 1, 1) || ExpenseDate.Date > DateTime.Today)
        {
            yield return new ValidationResult("Please choose a valid expense date.", new[] { nameof(ExpenseDate) });
        }
    }
}

public sealed class ExpenseListViewModel : IValidatableObject
{
    public IReadOnlyList<ExpenseViewModel> Expenses { get; set; } = Array.Empty<ExpenseViewModel>();
    public IReadOnlyList<ExpenseCategoryOption> Categories { get; set; } = Array.Empty<ExpenseCategoryOption>();
    public IReadOnlyList<string> PaymentMethods { get; set; } = ExpensePaymentMethods.All;
    public string? SearchTerm { get; set; }
    [Range(1, 12, ErrorMessage = "Choose a valid month.")]
    public int? Month { get; set; }
    [Range(2000, 2200, ErrorMessage = "Enter a valid year.")]
    public int? Year { get; set; }
    [Range(1, int.MaxValue, ErrorMessage = "Choose a valid category.")]
    public int? CategoryId { get; set; }
    public string? PaymentMethod { get; set; }
    [DataType(DataType.Date)]
    public DateTime? FromDate { get; set; }
    [DataType(DataType.Date)]
    public DateTime? ToDate { get; set; }
    public string SortBy { get; set; } = "date";
    public string SortDirection { get; set; } = "desc";
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public int TotalCount { get; set; }
    public int TotalPages => Math.Max(1, (int)Math.Ceiling(TotalCount / (double)PageSize));
    public bool HasPreviousPage => Page > 1;
    public bool HasNextPage => Page < TotalPages;
    public string CurrencyCode { get; set; } = "USD";
    public bool HasFilters => !string.IsNullOrWhiteSpace(SearchTerm) || Month.HasValue || Year.HasValue
        || CategoryId.HasValue || !string.IsNullOrWhiteSpace(PaymentMethod) || FromDate.HasValue || ToDate.HasValue;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (FromDate.HasValue && ToDate.HasValue && FromDate.Value.Date > ToDate.Value.Date)
        {
            yield return new ValidationResult("The start date must be on or before the end date.", new[] { nameof(FromDate), nameof(ToDate) });
        }
    }
}

public sealed record ExpenseCategoryOption(int CategoryId, string Name, string Icon, string ColorCode);

public static class ExpensePaymentMethods
{
    public static readonly IReadOnlyList<string> All = new[]
    {
        "Cash", "UPI", "Debit Card", "Credit Card", "Bank Transfer", "Other"
    };
}

public enum ExpenseOperationStatus
{
    Success,
    NotFound,
    InvalidCategory
}

public sealed record ExpenseOperationResult(ExpenseOperationStatus Status, int? ExpenseId = null);
