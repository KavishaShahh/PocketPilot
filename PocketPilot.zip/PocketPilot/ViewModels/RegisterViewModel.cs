using System.ComponentModel.DataAnnotations;

namespace PocketPilot.ViewModels;

public sealed class RegisterViewModel
{
    [Required(ErrorMessage = "Tell us your name to get started.")]
    [StringLength(100)]
    [Display(Name = "Name")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    [Display(Name = "Email address")]
    public string Email { get; set; } = string.Empty;

    [Required]
    [StringLength(100, MinimumLength = 8, ErrorMessage = "Use at least 8 characters.")]
    [DataType(DataType.Password)]
    [RegularExpression(@"^(?=.*\d).+$", ErrorMessage = "Add at least one number to your password.")]
    public string Password { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "Those passwords do not match yet.")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = string.Empty;

    [StringLength(50)]
    [Display(Name = "Student ID (optional)")]
    public string? StudentId { get; set; }

    [StringLength(150)]
    [Display(Name = "College or university (optional)")]
    public string? CollegeName { get; set; }

    [Range(typeof(decimal), "0", "100000000", ErrorMessage = "Enter a valid monthly budget.")]
    [Display(Name = "Monthly budget preference (optional)")]
    public decimal? MonthlyBudgetPreference { get; set; }

    [Required]
    [RegularExpression(@"^[A-Z]{3}$", ErrorMessage = "Use a three-letter currency code, such as USD.")]
    [Display(Name = "Default currency")]
    public string DefaultCurrency { get; set; } = "USD";
}