using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Text;
using PocketPilot.Models;
using PocketPilot.Services;
using PocketPilot.ViewModels;

namespace PocketPilot.Controllers;

[Authorize]
public sealed class ExpensesController : Controller
{
    private readonly IExpenseService _expenseService;
    private readonly UserManager<ApplicationUser> _userManager;

    public ExpensesController(IExpenseService expenseService, UserManager<ApplicationUser> userManager)
    {
        _expenseService = expenseService;
        _userManager = userManager;
    }

    [HttpGet]
    public async Task<IActionResult> Index([FromQuery] ExpenseListViewModel filters)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        if (!ModelState.IsValid)
        {
            var viewModel = await _expenseService.GetExpensesAsync(userId, new ExpenseListViewModel
            {
                Page = 1,
                PageSize = filters.PageSize,
                CurrencyCode = await _expenseService.GetCurrencyCodeAsync(userId),
                Categories = await _expenseService.GetCategoriesAsync(userId),
                PaymentMethods = ExpensePaymentMethods.All
            });
            viewModel.SearchTerm = filters.SearchTerm;
            viewModel.Month = filters.Month;
            viewModel.Year = filters.Year;
            viewModel.CategoryId = filters.CategoryId;
            viewModel.PaymentMethod = filters.PaymentMethod;
            viewModel.FromDate = filters.FromDate;
            viewModel.ToDate = filters.ToDate;
            viewModel.SortBy = filters.SortBy;
            viewModel.SortDirection = filters.SortDirection;
            ViewData["FilterErrors"] = ModelState.Values.SelectMany(value => value.Errors)
                .Select(error => error.ErrorMessage).Where(message => !string.IsNullOrWhiteSpace(message)).ToArray();
            return View(viewModel);
        }

        return View(await _expenseService.GetExpensesAsync(userId, filters));
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        await PopulateFormDataAsync(userId);
        return View(new ExpenseViewModel
        {
            ExpenseDate = DateTime.Today,
            PaymentMethod = "Cash",
            CurrencyCode = await _expenseService.GetCurrencyCodeAsync(userId)
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ExpenseViewModel model)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        if (model.CategoryId.HasValue && !await _expenseService.IsCategoryAvailableAsync(userId, model.CategoryId.Value))
        {
            ModelState.AddModelError(nameof(model.CategoryId), "Please select an expense category available to your account.");
        }

        if (!ModelState.IsValid)
        {
            model.CurrencyCode = await _expenseService.GetCurrencyCodeAsync(userId);
            await PopulateFormDataAsync(userId);
            return View(model);
        }

        var result = await _expenseService.CreateExpenseAsync(userId, model);
        if (result.Status == ExpenseOperationStatus.InvalidCategory)
        {
            ModelState.AddModelError(nameof(model.CategoryId), "Please select an expense category available to your account.");
            await PopulateFormDataAsync(userId);
            return View(model);
        }

        TempData["ExpenseSuccess"] = "Expense added successfully.";
        return RedirectToAction(nameof(Details), new { id = result.ExpenseId });
    }

    [HttpGet]
    public async Task<IActionResult> DownloadStatement([FromQuery] ExpenseListViewModel filters)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        if (!ModelState.IsValid)
        {
            return BadRequest("Please correct the expense filters before downloading the statement.");
        }

        var expenses = await _expenseService.GetExpenseStatementAsync(userId, filters);
        var csv = new StringBuilder();
        csv.AppendLine("Date,Description,Category,Payment Method,Amount,Currency,Notes");

        foreach (var expense in expenses)
        {
            csv.Append(CsvEscape(expense.ExpenseDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture))).Append(',')
                .Append(CsvEscape(expense.Description)).Append(',')
                .Append(CsvEscape(expense.CategoryName)).Append(',')
                .Append(CsvEscape(expense.PaymentMethod)).Append(',')
                .Append(expense.Amount.ToString("0.00", CultureInfo.InvariantCulture)).Append(',')
                .Append(CsvEscape(expense.CurrencyCode)).Append(',')
                .Append(CsvEscape(expense.Notes ?? string.Empty)).AppendLine();
        }

        var content = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(csv.ToString())).ToArray();
        var fileName = $"PocketPilot-Expenses-{DateTime.Today:yyyyMMdd}.csv";
        return File(content, "text/csv; charset=utf-8", fileName);
    }

    private static string CsvEscape(string value)
    {
        // Prevent spreadsheet formula execution for text fields in downloaded CSV files.
        if (!string.IsNullOrEmpty(value) && value[0] is '=' or '+' or '-' or '@' or '\t' or '\r')
        {
            value = "'" + value;
        }

        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        var expense = await _expenseService.GetExpenseAsync(userId, id);
        return expense is null ? NotFound() : View(expense);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        var expense = await _expenseService.GetExpenseAsync(userId, id);
        if (expense is null)
        {
            return NotFound();
        }

        await PopulateFormDataAsync(userId);
        return View(expense);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ExpenseViewModel model)
    {
        if (id != model.ExpenseId)
        {
            return BadRequest();
        }

        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        if (model.CategoryId.HasValue && !await _expenseService.IsCategoryAvailableAsync(userId, model.CategoryId.Value))
        {
            ModelState.AddModelError(nameof(model.CategoryId), "Please select an expense category available to your account.");
        }

        if (!ModelState.IsValid)
        {
            model.CurrencyCode = await _expenseService.GetCurrencyCodeAsync(userId);
            await PopulateFormDataAsync(userId);
            return View(model);
        }

        var result = await _expenseService.UpdateExpenseAsync(userId, id, model);
        if (result.Status == ExpenseOperationStatus.NotFound)
        {
            return NotFound();
        }

        if (result.Status == ExpenseOperationStatus.InvalidCategory)
        {
            ModelState.AddModelError(nameof(model.CategoryId), "Please select an expense category available to your account.");
            await PopulateFormDataAsync(userId);
            return View(model);
        }

        TempData["ExpenseSuccess"] = "Expense updated successfully.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        var expense = await _expenseService.GetExpenseAsync(userId, id);
        return expense is null ? NotFound() : View(expense);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var userId = CurrentUserId();
        if (userId is null)
        {
            return Challenge();
        }

        if (!await _expenseService.DeleteExpenseAsync(userId, id))
        {
            return NotFound();
        }

        TempData["ExpenseSuccess"] = "Expense deleted successfully.";
        return RedirectToAction(nameof(Index));
    }

    private string? CurrentUserId() => _userManager.GetUserId(User);

    private async Task PopulateFormDataAsync(string userId)
    {
        ViewData["Categories"] = await _expenseService.GetCategoriesAsync(userId);
        ViewData["PaymentMethods"] = ExpensePaymentMethods.All;
        ViewData["CurrencyCode"] = await _expenseService.GetCurrencyCodeAsync(userId);
    }
}
