using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PocketPilot.Models;
using PocketPilot.Services;
using PocketPilot.ViewModels;

namespace PocketPilot.Controllers;

[Authorize]
public class BudgetController : Controller
{
    private readonly IBudgetService _budgetService;
    private readonly UserManager<ApplicationUser> _userManager;

    public BudgetController(IBudgetService budgetService, UserManager<ApplicationUser> userManager)
    {
        _budgetService = budgetService;
        _userManager = userManager;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var viewModel = await BuildIndexViewModelAsync(userId);
        return View(viewModel);
    }

    [HttpGet]
    public IActionResult Current() => RedirectToAction(nameof(Index));

    [HttpGet]
    public async Task<IActionResult> Previous()
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var viewModel = await BuildIndexViewModelAsync(userId);
        ViewData["ShowPreviousOnly"] = true;
        return View(nameof(Index), viewModel);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var today = DateTime.Today;
        return View(new BudgetViewModel
        {
            BudgetMonth = today.Month,
            BudgetYear = today.Year,
            CurrencyCode = await _budgetService.GetCurrencyCodeAsync(userId)
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(BudgetViewModel model)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        model.CurrencyCode = await _budgetService.GetCurrencyCodeAsync(userId);
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await _budgetService.CreateBudgetAsync(userId, model);
        if (result.Status == BudgetOperationStatus.Duplicate)
        {
            ModelState.AddModelError(nameof(model.BudgetMonth), "You already have a budget for this month.");
            return View(model);
        }

        TempData["BudgetSuccess"] = "Your budget was created.";
        return RedirectToAction(nameof(Details), new { id = result.BudgetId });
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var model = await _budgetService.GetBudgetAsync(userId, id);
        return model is null ? NotFound() : View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var model = await _budgetService.GetBudgetAsync(userId, id);
        return model is null ? NotFound() : View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, BudgetViewModel model)
    {
        if (id != model.BudgetId)
        {
            return BadRequest();
        }

        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        model.CurrencyCode = await _budgetService.GetCurrencyCodeAsync(userId);
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var result = await _budgetService.UpdateBudgetAsync(userId, id, model);
        if (result.Status == BudgetOperationStatus.NotFound)
        {
            return NotFound();
        }

        if (result.Status == BudgetOperationStatus.Duplicate)
        {
            ModelState.AddModelError(nameof(model.BudgetMonth), "You already have a budget for this month.");
            return View(model);
        }

        TempData["BudgetSuccess"] = "Your budget was updated.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var model = await _budgetService.GetBudgetAsync(userId, id);
        return model is null ? NotFound() : View(model);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        if (!await _budgetService.DeleteBudgetAsync(userId, id))
        {
            return NotFound();
        }

        TempData["BudgetSuccess"] = "The budget was deleted.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DuplicatePrevious()
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        var result = await _budgetService.DuplicatePreviousBudgetAsync(userId);
        switch (result.Status)
        {
            case BudgetOperationStatus.Success:
                TempData["BudgetSuccess"] = "Last month's plan was copied into this month.";
                return RedirectToAction(nameof(Details), new { id = result.BudgetId });
            case BudgetOperationStatus.Duplicate:
                TempData["BudgetError"] = "You already have a budget for this month.";
                break;
            default:
                TempData["BudgetError"] = "There is no budget for last month to duplicate.";
                break;
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reset(int id)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrWhiteSpace(userId))
        {
            return Challenge();
        }

        if (!await _budgetService.ResetBudgetAsync(userId, id))
        {
            return NotFound();
        }

        TempData["BudgetSuccess"] = "Category allocations were reset. Your total budget and recorded expenses were kept.";
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task<BudgetIndexViewModel> BuildIndexViewModelAsync(string userId)
    {
        var budgets = await _budgetService.GetBudgetsAsync(userId);
        var previousBudgets = await _budgetService.GetPreviousBudgetsAsync(userId);
        var today = DateTime.Today;
        return new BudgetIndexViewModel
        {
            CurrencyCode = await _budgetService.GetCurrencyCodeAsync(userId),
            CurrentBudget = budgets.FirstOrDefault(item => item.BudgetMonth == today.Month && item.BudgetYear == today.Year),
            Budgets = budgets,
            PreviousBudgets = previousBudgets
        };
    }
}