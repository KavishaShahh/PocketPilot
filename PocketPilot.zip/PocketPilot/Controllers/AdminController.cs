using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PocketPilot.Models;

namespace PocketPilot.Controllers;

[Authorize(Roles = IdentityRoles.Admin)]
[Route("Admin")]
public class AdminController : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();
}