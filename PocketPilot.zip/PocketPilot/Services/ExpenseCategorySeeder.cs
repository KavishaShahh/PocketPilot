using Microsoft.EntityFrameworkCore;
using PocketPilot.Data;
using PocketPilot.Models;

namespace PocketPilot.Services;

public sealed class ExpenseCategorySeeder
{
    private static readonly (string Name, string Icon, string Color, string Description)[] StarterCategories =
    {
        ("Food", "bi bi-basket2", "#47916C", "Meals, groceries, and snacks"),
        ("Travel", "bi bi-bus-front", "#4887BC", "Transport and travel"),
        ("Education", "bi bi-book", "#6E5AE6", "Books, supplies, and study costs"),
        ("Entertainment", "bi bi-controller", "#CE6884", "Fun, events, and subscriptions"),
        ("Shopping", "bi bi-bag", "#D77E4E", "Personal and household shopping"),
        ("Health", "bi bi-heart-pulse", "#C75F77", "Health and wellbeing"),
        ("Bills", "bi bi-receipt", "#B48831", "Bills and recurring costs"),
        ("Emergency", "bi bi-life-preserver", "#5844D0", "Unexpected expenses"),
        ("Other", "bi bi-three-dots", "#72778A", "Everything else")
    };

    private readonly ApplicationDbContext _dbContext;

    public ExpenseCategorySeeder(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task SeedAsync()
    {
        var names = StarterCategories.Select(item => item.Name).ToArray();
        var existingNames = await _dbContext.Categories
            .Where(category => category.UserId == null && names.Contains(category.Name))
            .Select(category => category.Name)
            .ToListAsync();

        var missingCategories = StarterCategories
            .Where(category => !existingNames.Contains(category.Name, StringComparer.OrdinalIgnoreCase))
            .Select(category => new Category
            {
                Name = category.Name,
                Icon = category.Icon,
                ColorCode = category.Color,
                Description = category.Description,
                IsDefault = true,
                UserId = null
            })
            .ToArray();

        if (missingCategories.Length == 0)
        {
            return;
        }

        _dbContext.Categories.AddRange(missingCategories);
        await _dbContext.SaveChangesAsync();
    }
}
