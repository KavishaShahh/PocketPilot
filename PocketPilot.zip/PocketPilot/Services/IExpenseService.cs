using PocketPilot.ViewModels;

namespace PocketPilot.Services;

public interface IExpenseService
{
    Task<ExpenseListViewModel> GetExpensesAsync(string userId, ExpenseListViewModel filters);
    Task<IReadOnlyList<ExpenseViewModel>> GetExpenseStatementAsync(string userId, ExpenseListViewModel filters);
    Task<ExpenseViewModel?> GetExpenseAsync(string userId, int expenseId);
    Task<IReadOnlyList<ExpenseCategoryOption>> GetCategoriesAsync(string userId);
    Task<string> GetCurrencyCodeAsync(string userId);
    Task<bool> IsCategoryAvailableAsync(string userId, int categoryId);
    Task<ExpenseOperationResult> CreateExpenseAsync(string userId, ExpenseViewModel model);
    Task<ExpenseOperationResult> UpdateExpenseAsync(string userId, int expenseId, ExpenseViewModel model);
    Task<bool> DeleteExpenseAsync(string userId, int expenseId);
}
