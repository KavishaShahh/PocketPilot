using Microsoft.AspNetCore.Identity;
using PocketPilot.Models;

namespace PocketPilot.Services;

public sealed class IdentitySeeder
{
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IConfiguration _configuration;
    private readonly ILogger<IdentitySeeder> _logger;

    public IdentitySeeder(
        RoleManager<IdentityRole> roleManager,
        UserManager<ApplicationUser> userManager,
        IConfiguration configuration,
        ILogger<IdentitySeeder> logger)
    {
        _roleManager = roleManager;
        _userManager = userManager;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task SeedAsync(bool isDevelopment)
    {
        await EnsureRoleAsync(IdentityRoles.Admin);
        await EnsureRoleAsync(IdentityRoles.Student);

        if (!isDevelopment)
        {
            return;
        }

        await EnsureDevelopmentUserAsync(
            "DemoAccounts:Admin", "admin@pocketpilot.local", "PocketPilot Admin", IdentityRoles.Admin);
        await EnsureDevelopmentUserAsync(
            "DemoAccounts:Student", "student@pocketpilot.local", "PocketPilot Demo Student", IdentityRoles.Student);
    }

    private async Task EnsureRoleAsync(string roleName)
    {
        if (!await _roleManager.RoleExistsAsync(roleName))
        {
            var result = await _roleManager.CreateAsync(new IdentityRole(roleName));
            if (!result.Succeeded && !await _roleManager.RoleExistsAsync(roleName))
            {
                throw new InvalidOperationException($"Could not create the {roleName} role: {string.Join("; ", result.Errors.Select(error => error.Description))}");
            }
        }
    }

    private async Task EnsureDevelopmentUserAsync(string section, string email, string name, string role)
    {
        var password = _configuration[$"{section}:Password"];
        if (string.IsNullOrWhiteSpace(password))
        {
            _logger.LogWarning("Development seed password is missing for {Email}; skipping this demo account.", email);
            return;
        }

        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
        {
            user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                EmailConfirmed = true,
                Name = name,
                DefaultCurrency = "USD",
                IsActive = true,
                CreatedDate = DateTime.UtcNow
            };

            var result = await _userManager.CreateAsync(user, password);
            if (!result.Succeeded)
            {
                throw new InvalidOperationException($"Could not create development account {email}: {string.Join("; ", result.Errors.Select(error => error.Description))}");
            }
        }

        if (!await _userManager.IsInRoleAsync(user, role))
        {
            var result = await _userManager.AddToRoleAsync(user, role);
            if (!result.Succeeded)
            {
                throw new InvalidOperationException($"Could not assign the {role} role to {email}: {string.Join("; ", result.Errors.Select(error => error.Description))}");
            }
        }
    }
}