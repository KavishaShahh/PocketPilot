using Microsoft.EntityFrameworkCore;
using PocketPilot.Data;
using PocketPilot.Models;
using PocketPilot.ViewModels;

namespace PocketPilot.Services;

public sealed class BudgetService : IBudgetService
{
    private readonly ApplicationDbContext _dbContext;

    public BudgetService(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<string> GetCurrencyCodeAsync(string userId)
    {
        EnsureUserId(userId);
        return await _dbContext.Users.AsNoTracking()
            .Where(user => user.Id == userId)
            .Select(user => user.DefaultCurrency)
            .SingleOrDefaultAsync() ?? "USD";
    }

    public async Task<BudgetViewModel?> GetCurrentBudgetAsync(string userId, DateTime? asOf = null)
    {
        EnsureUserId(userId);
        var period = asOf ?? DateTime.Today;
        var budget = await _dbContext.Budgets.AsNoTracking()
            .SingleOrDefaultAsync(item => item.UserId == userId
                && item.BudgetMonth == period.Month
                && item.BudgetYear == period.Year);

        return budget is null ? null : await MapWithSpendingAsync(budget, await GetCurrencyCodeAsync(userId));
    }

    public async Task<IReadOnlyList<BudgetViewModel>> GetBudgetsAsync(string userId)
    {
        EnsureUserId(userId);
        var budgets = await _dbContext.Budgets.AsNoTracking()
            .Where(item => item.UserId == userId)
            .OrderByDescending(item => item.BudgetYear)
            .ThenByDescending(item => item.BudgetMonth)
            .ToListAsync();

        return await MapBudgetsWithSpendingAsync(budgets, userId);
    }

    public async Task<IReadOnlyList<BudgetViewModel>> GetPreviousBudgetsAsync(string userId, DateTime? asOf = null)
    {
        var period = asOf ?? DateTime.Today;
        var budgets = await GetBudgetsAsync(userId);
        return budgets
            .Where(item => item.BudgetYear * 100 + item.BudgetMonth < period.Year * 100 + period.Month)
            .ToArray();
    }

    public async Task<BudgetViewModel?> GetBudgetAsync(string userId, int budgetId)
    {
        EnsureUserId(userId);
        var budget = await _dbContext.Budgets.AsNoTracking()
            .SingleOrDefaultAsync(item => item.BudgetId == budgetId && item.UserId == userId);
        return budget is null ? null : await MapWithSpendingAsync(budget, await GetCurrencyCodeAsync(userId));
    }

    public async Task<BudgetOperationResult> CreateBudgetAsync(string userId, BudgetViewModel model)
    {
        EnsureUserId(userId);
        if (await BudgetPeriodExistsAsync(userId, model.BudgetMonth, model.BudgetYear))
        {
            return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
        }

        var budget = new Budget { UserId = userId };
        ApplyFormValues(budget, model);
        _dbContext.Budgets.Add(budget);

        try
        {
            await _dbContext.SaveChangesAsync();
            return new BudgetOperationResult(BudgetOperationStatus.Success, budget.BudgetId);
        }
        catch (DbUpdateException)
        {
            if (await BudgetPeriodExistsAsync(userId, model.BudgetMonth, model.BudgetYear))
            {
                return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
            }

            throw;
        }
    }

    public async Task<BudgetOperationResult> UpdateBudgetAsync(string userId, int budgetId, BudgetViewModel model)
    {
        EnsureUserId(userId);
        var budget = await _dbContext.Budgets
            .SingleOrDefaultAsync(item => item.BudgetId == budgetId && item.UserId == userId);
        if (budget is null)
        {
            return new BudgetOperationResult(BudgetOperationStatus.NotFound);
        }

        if (await _dbContext.Budgets.AnyAsync(item => item.UserId == userId
            && item.BudgetId != budgetId
            && item.BudgetMonth == model.BudgetMonth
            && item.BudgetYear == model.BudgetYear))
        {
            return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
        }

        ApplyFormValues(budget, model);
        budget.UpdatedDate = DateTime.UtcNow;
        try
        {
            await _dbContext.SaveChangesAsync();
            return new BudgetOperationResult(BudgetOperationStatus.Success, budget.BudgetId);
        }
        catch (DbUpdateException)
        {
            if (await _dbContext.Budgets.AnyAsync(item => item.UserId == userId
                && item.BudgetId != budgetId
                && item.BudgetMonth == model.BudgetMonth
                && item.BudgetYear == model.BudgetYear))
            {
                return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
            }

            throw;
        }
    }

    public async Task<bool> DeleteBudgetAsync(string userId, int budgetId)
    {
        EnsureUserId(userId);
        var budget = await _dbContext.Budgets
            .SingleOrDefaultAsync(item => item.BudgetId == budgetId && item.UserId == userId);
        if (budget is null)
        {
            return false;
        }

        _dbContext.Budgets.Remove(budget);
        await _dbContext.SaveChangesAsync();
        return true;
    }

    public async Task<BudgetOperationResult> DuplicatePreviousBudgetAsync(string userId, DateTime? asOf = null)
    {
        EnsureUserId(userId);
        var currentPeriod = asOf ?? DateTime.Today;
        if (await BudgetPeriodExistsAsync(userId, currentPeriod.Month, currentPeriod.Year))
        {
            return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
        }

        var previousPeriod = currentPeriod.AddMonths(-1);
        var previous = await _dbContext.Budgets.AsNoTracking()
            .SingleOrDefaultAsync(item => item.UserId == userId
                && item.BudgetMonth == previousPeriod.Month
                && item.BudgetYear == previousPeriod.Year);
        if (previous is null)
        {
            return new BudgetOperationResult(BudgetOperationStatus.NoPreviousBudget);
        }

        var copy = new Budget
        {
            UserId = userId,
            BudgetMonth = currentPeriod.Month,
            BudgetYear = currentPeriod.Year,
            TotalBudget = previous.TotalBudget,
            FoodBudget = previous.FoodBudget,
            TravelBudget = previous.TravelBudget,
            StudyBudget = previous.StudyBudget,
            EntertainmentBudget = previous.EntertainmentBudget,
            ShoppingBudget = previous.ShoppingBudget,
            EmergencyBudget = previous.EmergencyBudget,
            OtherBudget = previous.OtherBudget,
            CreatedDate = DateTime.UtcNow
        };

        _dbContext.Budgets.Add(copy);
        try
        {
            await _dbContext.SaveChangesAsync();
            return new BudgetOperationResult(BudgetOperationStatus.Success, copy.BudgetId);
        }
        catch (DbUpdateException)
        {
            if (await BudgetPeriodExistsAsync(userId, currentPeriod.Month, currentPeriod.Year))
            {
                return new BudgetOperationResult(BudgetOperationStatus.Duplicate);
            }

            throw;
        }
    }

    public async Task<bool> ResetBudgetAsync(string userId, int budgetId)
    {
        EnsureUserId(userId);
        var budget = await _dbContext.Budgets
            .SingleOrDefaultAsync(item => item.BudgetId == budgetId && item.UserId == userId);
        if (budget is null)
        {
            return false;
        }

        budget.FoodBudget = 0;
        budget.TravelBudget = 0;
        budget.StudyBudget = 0;
        budget.EntertainmentBudget = 0;
        budget.ShoppingBudget = 0;
        budget.EmergencyBudget = 0;
        budget.OtherBudget = 0;
        budget.UpdatedDate = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
        return true;
    }

    private async Task<IReadOnlyList<BudgetViewModel>> MapBudgetsWithSpendingAsync(
        IReadOnlyList<Budget> budgets,
        string userId)
    {
        if (budgets.Count == 0)
        {
            return Array.Empty<BudgetViewModel>();
        }

        var first = budgets.MinBy(item => item.BudgetYear * 100 + item.BudgetMonth)!;
        var last = budgets.MaxBy(item => item.BudgetYear * 100 + item.BudgetMonth)!;
        var start = new DateTime(first.BudgetYear, first.BudgetMonth, 1);
        var end = new DateTime(last.BudgetYear, last.BudgetMonth, 1).AddMonths(1);
        var spending = await _dbContext.Expenses.AsNoTracking()
            .Where(expense => expense.UserId == userId && expense.ExpenseDate >= start && expense.ExpenseDate < end)
            .GroupBy(expense => new { expense.ExpenseDate.Year, expense.ExpenseDate.Month })
            .Select(group => new { group.Key.Year, group.Key.Month, Total = group.Sum(expense => expense.Amount) })
            .ToDictionaryAsync(item => item.Year * 100 + item.Month, item => item.Total);
        var currency = await GetCurrencyCodeAsync(userId);

        return budgets.Select(budget => Map(budget,
            spending.GetValueOrDefault(budget.BudgetYear * 100 + budget.BudgetMonth), currency)).ToArray();
    }

    private async Task<BudgetViewModel> MapWithSpendingAsync(Budget budget, string currencyCode)
    {
        var start = new DateTime(budget.BudgetYear, budget.BudgetMonth, 1);
        var end = start.AddMonths(1);
        var spent = await _dbContext.Expenses.AsNoTracking()
            .Where(expense => expense.UserId == budget.UserId && expense.ExpenseDate >= start && expense.ExpenseDate < end)
            .SumAsync(expense => (decimal?)expense.Amount) ?? 0m;
        return Map(budget, spent, currencyCode);
    }

    private static BudgetViewModel Map(Budget budget, decimal spent, string currencyCode) => new()
    {
        BudgetId = budget.BudgetId,
        BudgetMonth = budget.BudgetMonth,
        BudgetYear = budget.BudgetYear,
        TotalBudget = budget.TotalBudget,
        FoodBudget = budget.FoodBudget,
        TravelBudget = budget.TravelBudget,
        StudyBudget = budget.StudyBudget,
        EntertainmentBudget = budget.EntertainmentBudget,
        ShoppingBudget = budget.ShoppingBudget,
        EmergencyBudget = budget.EmergencyBudget,
        OtherBudget = budget.OtherBudget,
        SpentAmount = spent,
        CurrencyCode = currencyCode
    };

    private async Task<bool> BudgetPeriodExistsAsync(string userId, int month, int year) =>
        await _dbContext.Budgets.AsNoTracking().AnyAsync(item => item.UserId == userId
            && item.BudgetMonth == month && item.BudgetYear == year);

    private static void ApplyFormValues(Budget budget, BudgetViewModel model)
    {
        budget.BudgetMonth = model.BudgetMonth;
        budget.BudgetYear = model.BudgetYear;
        budget.TotalBudget = model.TotalBudget;
        budget.FoodBudget = model.FoodBudget;
        budget.TravelBudget = model.TravelBudget;
        budget.StudyBudget = model.StudyBudget;
        budget.EntertainmentBudget = model.EntertainmentBudget;
        budget.ShoppingBudget = model.ShoppingBudget;
        budget.EmergencyBudget = model.EmergencyBudget;
        budget.OtherBudget = model.OtherBudget;
    }

    private static void EnsureUserId(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
        {
            throw new ArgumentException("A signed-in user ID is required.", nameof(userId));
        }
    }
}