using PocketPilot.ViewModels;

namespace PocketPilot.Services;

public interface IBudgetService
{
    Task<string> GetCurrencyCodeAsync(string userId);
    Task<BudgetViewModel?> GetCurrentBudgetAsync(string userId, DateTime? asOf = null);
    Task<IReadOnlyList<BudgetViewModel>> GetBudgetsAsync(string userId);
    Task<IReadOnlyList<BudgetViewModel>> GetPreviousBudgetsAsync(string userId, DateTime? asOf = null);
    Task<BudgetViewModel?> GetBudgetAsync(string userId, int budgetId);
    Task<BudgetOperationResult> CreateBudgetAsync(string userId, BudgetViewModel model);
    Task<BudgetOperationResult> UpdateBudgetAsync(string userId, int budgetId, BudgetViewModel model);
    Task<bool> DeleteBudgetAsync(string userId, int budgetId);
    Task<BudgetOperationResult> DuplicatePreviousBudgetAsync(string userId, DateTime? asOf = null);
    Task<bool> ResetBudgetAsync(string userId, int budgetId);
}