using Microsoft.EntityFrameworkCore;
using PocketPilot.Data;
using PocketPilot.Models;
using PocketPilot.ViewModels;

namespace PocketPilot.Services;

public sealed class ExpenseService : IExpenseService
{
    private const int MaximumPageSize = 50;
    private readonly ApplicationDbContext _dbContext;

    public ExpenseService(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<ExpenseListViewModel> GetExpensesAsync(string userId, ExpenseListViewModel filters)
    {
        EnsureUserId(userId);
        var page = Math.Max(1, filters.Page);
        var pageSize = Math.Clamp(filters.PageSize, 1, MaximumPageSize);
        var query = _dbContext.Expenses.AsNoTracking()
            .Where(expense => expense.UserId == userId);

        if (!string.IsNullOrWhiteSpace(filters.SearchTerm))
        {
            var term = filters.SearchTerm.Trim();
            query = query.Where(expense => expense.Description.Contains(term)
                || (expense.Notes != null && expense.Notes.Contains(term)));
        }

        if (filters.Month is >= 1 and <= 12)
        {
            query = query.Where(expense => expense.ExpenseDate.Month == filters.Month.Value);
        }

        if (filters.Year is >= 2000 and <= 2200)
        {
            query = query.Where(expense => expense.ExpenseDate.Year == filters.Year.Value);
        }

        if (filters.CategoryId.HasValue)
        {
            var categoryId = filters.CategoryId.Value;
            query = query.Where(expense => expense.CategoryId == categoryId);
        }

        if (!string.IsNullOrWhiteSpace(filters.PaymentMethod)
            && ExpensePaymentMethods.All.Contains(filters.PaymentMethod, StringComparer.Ordinal))
        {
            query = query.Where(expense => expense.PaymentMethod == filters.PaymentMethod);
        }

        if (filters.FromDate.HasValue)
        {
            var from = filters.FromDate.Value.Date;
            query = query.Where(expense => expense.ExpenseDate >= from);
        }

        if (filters.ToDate.HasValue)
        {
            var toExclusive = filters.ToDate.Value.Date.AddDays(1);
            query = query.Where(expense => expense.ExpenseDate < toExclusive);
        }

        var totalCount = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(totalCount / (double)pageSize));
        page = Math.Min(page, totalPages);
        var sortBy = filters.SortBy == "amount" ? "amount" : "date";
        var ascending = filters.SortDirection.Equals("asc", StringComparison.OrdinalIgnoreCase);
        query = (sortBy, ascending) switch
        {
            ("amount", true) => query.OrderBy(expense => expense.Amount).ThenBy(expense => expense.ExpenseId),
            ("amount", false) => query.OrderByDescending(expense => expense.Amount).ThenByDescending(expense => expense.ExpenseId),
            (_, true) => query.OrderBy(expense => expense.ExpenseDate).ThenBy(expense => expense.ExpenseId),
            _ => query.OrderByDescending(expense => expense.ExpenseDate).ThenByDescending(expense => expense.ExpenseId)
        };

        var rows = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(expense => new ExpenseViewModel
            {
                ExpenseId = expense.ExpenseId,
                Amount = expense.Amount,
                CategoryId = expense.CategoryId,
                CategoryName = expense.Category.Name,
                CategoryIcon = expense.Category.Icon,
                CategoryColor = expense.Category.ColorCode,
                Description = expense.Description,
                ExpenseDate = expense.ExpenseDate,
                PaymentMethod = expense.PaymentMethod,
                Notes = expense.Notes,
                CreatedDate = expense.CreatedDate
            })
            .ToListAsync();

        var currencyCode = await GetCurrencyCodeAsync(userId);
        foreach (var row in rows)
        {
            row.CurrencyCode = currencyCode;
        }

        var categories = await GetCategoriesAsync(userId);
        return new ExpenseListViewModel
        {
            Expenses = rows,
            Categories = categories,
            PaymentMethods = ExpensePaymentMethods.All,
            SearchTerm = filters.SearchTerm?.Trim(),
            Month = filters.Month,
            Year = filters.Year,
            CategoryId = filters.CategoryId,
            PaymentMethod = filters.PaymentMethod,
            FromDate = filters.FromDate,
            ToDate = filters.ToDate,
            SortBy = sortBy,
            SortDirection = ascending ? "asc" : "desc",
            Page = page,
            PageSize = pageSize,
            TotalCount = totalCount,
            CurrencyCode = currencyCode
        };
    }

    public async Task<IReadOnlyList<ExpenseViewModel>> GetExpenseStatementAsync(string userId, ExpenseListViewModel filters)
    {
        EnsureUserId(userId);
        var currencyCode = await GetCurrencyCodeAsync(userId);
        var query = _dbContext.Expenses.AsNoTracking()
            .Where(expense => expense.UserId == userId);

        // Apply the same filters used by the Expense history page.
        if (!string.IsNullOrWhiteSpace(filters.SearchTerm))
        {
            var term = filters.SearchTerm.Trim();
            query = query.Where(expense => expense.Description.Contains(term)
                || (expense.Notes != null && expense.Notes.Contains(term)));
        }

        if (filters.Month is >= 1 and <= 12)
        {
            query = query.Where(expense => expense.ExpenseDate.Month == filters.Month.Value);
        }

        if (filters.Year is >= 2000 and <= 2200)
        {
            query = query.Where(expense => expense.ExpenseDate.Year == filters.Year.Value);
        }

        if (filters.CategoryId.HasValue)
        {
            var categoryId = filters.CategoryId.Value;
            query = query.Where(expense => expense.CategoryId == categoryId);
        }

        if (!string.IsNullOrWhiteSpace(filters.PaymentMethod)
            && ExpensePaymentMethods.All.Contains(filters.PaymentMethod, StringComparer.Ordinal))
        {
            query = query.Where(expense => expense.PaymentMethod == filters.PaymentMethod);
        }

        if (filters.FromDate.HasValue)
        {
            var from = filters.FromDate.Value.Date;
            query = query.Where(expense => expense.ExpenseDate >= from);
        }

        if (filters.ToDate.HasValue)
        {
            var toExclusive = filters.ToDate.Value.Date.AddDays(1);
            query = query.Where(expense => expense.ExpenseDate < toExclusive);
        }

        var sortBy = filters.SortBy == "amount" ? "amount" : "date";
        var ascending = filters.SortDirection.Equals("asc", StringComparison.OrdinalIgnoreCase);
        query = (sortBy, ascending) switch
        {
            ("amount", true) => query.OrderBy(expense => expense.Amount).ThenBy(expense => expense.ExpenseId),
            ("amount", false) => query.OrderByDescending(expense => expense.Amount).ThenByDescending(expense => expense.ExpenseId),
            (_, true) => query.OrderBy(expense => expense.ExpenseDate).ThenBy(expense => expense.ExpenseId),
            _ => query.OrderByDescending(expense => expense.ExpenseDate).ThenByDescending(expense => expense.ExpenseId)
        };

        // Deliberately do not paginate: export every expense matching the current filters.
        var expenses = await query
            .Select(expense => new ExpenseViewModel
            {
                ExpenseId = expense.ExpenseId,
                Amount = expense.Amount,
                CategoryId = expense.CategoryId,
                CategoryName = expense.Category.Name,
                Description = expense.Description,
                ExpenseDate = expense.ExpenseDate,
                PaymentMethod = expense.PaymentMethod,
                Notes = expense.Notes,
                CreatedDate = expense.CreatedDate
            })
            .ToListAsync();

        foreach (var expense in expenses)
        {
            expense.CurrencyCode = currencyCode;
        }

        return expenses;
    }

    public async Task<ExpenseViewModel?> GetExpenseAsync(string userId, int expenseId)
    {
        EnsureUserId(userId);
        var currencyCode = await GetCurrencyCodeAsync(userId);
        return await _dbContext.Expenses.AsNoTracking()
            .Where(expense => expense.ExpenseId == expenseId && expense.UserId == userId)
            .Select(expense => new ExpenseViewModel
            {
                ExpenseId = expense.ExpenseId,
                Amount = expense.Amount,
                CategoryId = expense.CategoryId,
                CategoryName = expense.Category.Name,
                CategoryIcon = expense.Category.Icon,
                CategoryColor = expense.Category.ColorCode,
                Description = expense.Description,
                ExpenseDate = expense.ExpenseDate,
                PaymentMethod = expense.PaymentMethod,
                Notes = expense.Notes,
                CreatedDate = expense.CreatedDate,
                CurrencyCode = currencyCode
            })
            .SingleOrDefaultAsync();
    }

    public async Task<IReadOnlyList<ExpenseCategoryOption>> GetCategoriesAsync(string userId)
    {
        EnsureUserId(userId);
        return await _dbContext.Categories.AsNoTracking()
            .Where(category => category.UserId == null || category.UserId == userId)
            .OrderBy(category => category.Name)
            .Select(category => new ExpenseCategoryOption(category.CategoryId, category.Name, category.Icon, category.ColorCode))
            .ToListAsync();
    }

    public async Task<string> GetCurrencyCodeAsync(string userId)
    {
        EnsureUserId(userId);
        return await _dbContext.Users.AsNoTracking()
            .Where(user => user.Id == userId)
            .Select(user => user.DefaultCurrency)
            .SingleOrDefaultAsync() ?? "USD";
    }

    public async Task<bool> IsCategoryAvailableAsync(string userId, int categoryId)
    {
        EnsureUserId(userId);
        return await _dbContext.Categories.AsNoTracking().AnyAsync(category => category.CategoryId == categoryId
            && (category.UserId == null || category.UserId == userId));
    }

    public async Task<ExpenseOperationResult> CreateExpenseAsync(string userId, ExpenseViewModel model)
    {
        EnsureUserId(userId);
        if (!model.CategoryId.HasValue || !await IsCategoryAvailableAsync(userId, model.CategoryId.Value))
        {
            return new ExpenseOperationResult(ExpenseOperationStatus.InvalidCategory);
        }

        var expense = new Expense
        {
            UserId = userId,
            Amount = model.Amount,
            CategoryId = model.CategoryId.Value,
            Description = model.Description.Trim(),
            ExpenseDate = model.ExpenseDate.Date,
            PaymentMethod = model.PaymentMethod,
            Notes = NormalizeNotes(model.Notes),
            CreatedDate = DateTime.UtcNow
        };
        _dbContext.Expenses.Add(expense);
        await _dbContext.SaveChangesAsync();
        return new ExpenseOperationResult(ExpenseOperationStatus.Success, expense.ExpenseId);
    }

    public async Task<ExpenseOperationResult> UpdateExpenseAsync(string userId, int expenseId, ExpenseViewModel model)
    {
        EnsureUserId(userId);
        var expense = await _dbContext.Expenses
            .SingleOrDefaultAsync(item => item.ExpenseId == expenseId && item.UserId == userId);
        if (expense is null)
        {
            return new ExpenseOperationResult(ExpenseOperationStatus.NotFound);
        }

        if (!model.CategoryId.HasValue || !await IsCategoryAvailableAsync(userId, model.CategoryId.Value))
        {
            return new ExpenseOperationResult(ExpenseOperationStatus.InvalidCategory);
        }

        expense.Amount = model.Amount;
        expense.CategoryId = model.CategoryId.Value;
        expense.Description = model.Description.Trim();
        expense.ExpenseDate = model.ExpenseDate.Date;
        expense.PaymentMethod = model.PaymentMethod;
        expense.Notes = NormalizeNotes(model.Notes);
        await _dbContext.SaveChangesAsync();
        return new ExpenseOperationResult(ExpenseOperationStatus.Success, expense.ExpenseId);
    }

    public async Task<bool> DeleteExpenseAsync(string userId, int expenseId)
    {
        EnsureUserId(userId);
        var expense = await _dbContext.Expenses
            .SingleOrDefaultAsync(item => item.ExpenseId == expenseId && item.UserId == userId);
        if (expense is null)
        {
            return false;
        }

        _dbContext.Expenses.Remove(expense);
        await _dbContext.SaveChangesAsync();
        return true;
    }

    private static string? NormalizeNotes(string? notes) =>
        string.IsNullOrWhiteSpace(notes) ? null : notes.Trim();

    private static void EnsureUserId(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
        {
            throw new ArgumentException("A signed-in user ID is required.", nameof(userId));
        }
    }
}
