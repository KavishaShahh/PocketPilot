using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PocketPilot.Models;

public class ApplicationUser : IdentityUser
{
    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [StringLength(50)]
    public string? StudentId { get; set; }

    [StringLength(150)]
    public string? CollegeName { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal? MonthlyBudgetPreference { get; set; }

    [Required]
    [StringLength(10, MinimumLength = 3)]
    [RegularExpression("^[A-Z]{3,10}$", ErrorMessage = "Use an uppercase currency code, such as USD.")]
    public string DefaultCurrency { get; set; } = "USD";

    public int? DefaultExpenseCategoryId { get; set; }

    [StringLength(255)]
    [Url]
    public string? ProfilePicture { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [ForeignKey(nameof(DefaultExpenseCategoryId))]
    public Category? DefaultExpenseCategory { get; set; }

    public ICollection<Budget> Budgets { get; set; } = new List<Budget>();
    public ICollection<Expense> Expenses { get; set; } = new List<Expense>();
    public ICollection<Category> Categories { get; set; } = new List<Category>();
    public ICollection<SavingsGoal> SavingsGoals { get; set; } = new List<SavingsGoal>();
    public ICollection<SavingsContribution> SavingsContributions { get; set; } = new List<SavingsContribution>();
    public ICollection<UserChallenge> UserChallenges { get; set; } = new List<UserChallenge>();
    public ICollection<UserAchievement> UserAchievements { get; set; } = new List<UserAchievement>();
    public ICollection<BudgetAlert> BudgetAlerts { get; set; } = new List<BudgetAlert>();
}
