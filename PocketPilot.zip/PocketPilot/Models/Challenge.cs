using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class Challenge
{
    public int ChallengeId { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [Range(1, 365)]
    public int DurationDays { get; set; }

    [Range(typeof(decimal), "0.01", "9999999999999999.99")]
    public decimal? TargetAmount { get; set; }

    [StringLength(50)]
    public string? CategoryConstraint { get; set; }

    [Required]
    [StringLength(100)]
    public string BadgeReward { get; set; } = "First steps";

    [Required]
    [StringLength(20)]
    [RegularExpression("^(Easy|Medium|Hard)$")]
    public string Difficulty { get; set; } = "Easy";

    [Required]
    [StringLength(50)]
    public string Icon { get; set; } = "bi bi-trophy";

    public bool IsActive { get; set; } = true;

    public ICollection<UserChallenge> UserChallenges { get; set; } = new List<UserChallenge>();
}