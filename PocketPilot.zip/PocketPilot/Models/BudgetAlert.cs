using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class BudgetAlert
{
    public int BudgetAlertId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(500)]
    public string Message { get; set; } = string.Empty;

    [Required]
    [StringLength(20)]
    [RegularExpression("^(Info|Warning|Critical)$")]
    public string AlertLevel { get; set; } = "Info";

    [StringLength(50)]
    public string? CategoryTag { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public bool IsDismissed { get; set; }

    public ApplicationUser User { get; set; } = null!;
}