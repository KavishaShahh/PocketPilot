using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class Category
{
    public int CategoryId { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Icon { get; set; } = "bi bi-tag";

    [Required]
    [StringLength(20)]
    [RegularExpression("^#[0-9A-Fa-f]{6}$", ErrorMessage = "Use a six-digit hex colour, such as #6E5AE6.")]
    public string ColorCode { get; set; } = "#6E5AE6";

    [StringLength(200)]
    public string? Description { get; set; }

    public bool IsDefault { get; set; }

    [StringLength(450)]
    public string? UserId { get; set; }

    public ApplicationUser? User { get; set; }
    public ICollection<Expense> Expenses { get; set; } = new List<Expense>();
    public ICollection<ApplicationUser> DefaultForUsers { get; set; } = new List<ApplicationUser>();
}