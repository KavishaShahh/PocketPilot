using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class SavingsContribution
{
    public int ContributionId { get; set; }

    [Range(1, int.MaxValue)]
    public int SavingsGoalId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.01", "9999999999999999.99")]
    public decimal Amount { get; set; }

    [DataType(DataType.Date)]
    public DateTime ContributionDate { get; set; } = DateTime.Today;

    [StringLength(300)]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public SavingsGoal SavingsGoal { get; set; } = null!;
    public ApplicationUser User { get; set; } = null!;
}