using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class Expense
{
    public int ExpenseId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.01", "9999999999999999.99")]
    public decimal Amount { get; set; }

    [Range(1, int.MaxValue)]
    public int CategoryId { get; set; }

    [Required]
    [StringLength(100)]
    public string Description { get; set; } = string.Empty;

    [DataType(DataType.Date)]
    public DateTime ExpenseDate { get; set; } = DateTime.Today;

    [Required]
    [StringLength(50)]
    [RegularExpression("^(Cash|UPI|Debit Card|Credit Card|Bank Transfer|Other)$", ErrorMessage = "Choose a supported payment method.")]
    public string PaymentMethod { get; set; } = "Other";

    [StringLength(500)]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public ApplicationUser User { get; set; } = null!;
    public Category Category { get; set; } = null!;
}