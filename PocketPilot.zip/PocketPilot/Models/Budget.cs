using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PocketPilot.Models;

public class Budget : IValidatableObject
{
    public int BudgetId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Range(1, 12)]
    public int BudgetMonth { get; set; }

    [Range(2000, 2200)]
    public int BudgetYear { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal TotalBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal FoodBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal TravelBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal StudyBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal EntertainmentBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal ShoppingBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal EmergencyBudget { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal OtherBudget { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedDate { get; set; }

    public ApplicationUser User { get; set; } = null!;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        var allocationTotal = FoodBudget + TravelBudget + StudyBudget + EntertainmentBudget
            + ShoppingBudget + EmergencyBudget + OtherBudget;

        if (allocationTotal > TotalBudget)
        {
            yield return new ValidationResult(
                "Category allocations cannot exceed the total monthly budget.",
                new[] { nameof(FoodBudget), nameof(TravelBudget), nameof(StudyBudget), nameof(EntertainmentBudget), nameof(ShoppingBudget), nameof(EmergencyBudget), nameof(OtherBudget) });
        }
    }
}