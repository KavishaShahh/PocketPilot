using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PocketPilot.Models;

public class UserChallenge : IValidatableObject
{
    public int UserChallengeId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int ChallengeId { get; set; }

    [DataType(DataType.Date)]
    public DateTime StartDate { get; set; } = DateTime.Today;

    [DataType(DataType.Date)]
    public DateTime EndDate { get; set; }

    [Range(0, 100)]
    public int Progress { get; set; }

    [Required]
    [StringLength(20)]
    [RegularExpression("^(Active|Completed|Failed|Abandoned)$")]
    public string Status { get; set; } = "Active";

    [NotMapped]
    public bool IsCompleted
    {
        get => Status == "Completed";
        set => Status = value ? "Completed" : "Active";
    }

    [StringLength(300)]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public ApplicationUser User { get; set; } = null!;
    public Challenge Challenge { get; set; } = null!;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (EndDate.Date < StartDate.Date)
        {
            yield return new ValidationResult(
                "The challenge end date cannot be before its start date.",
                new[] { nameof(StartDate), nameof(EndDate) });
        }
    }
}