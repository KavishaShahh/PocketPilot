using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class UserAchievement
{
    public int UserAchievementId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int AchievementId { get; set; }

    public DateTime EarnedDate { get; set; } = DateTime.UtcNow;

    public ApplicationUser User { get; set; } = null!;
    public Achievement Achievement { get; set; } = null!;
}