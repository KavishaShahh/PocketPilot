namespace PocketPilot.Models;

public static class IdentityRoles
{
    public const string Admin = "Admin";
    public const string Student = "Student";
}