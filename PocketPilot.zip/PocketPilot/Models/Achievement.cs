using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class Achievement
{
    public int AchievementId { get; set; }

    [Required]
    [StringLength(50)]
    public string Code { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(300)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Icon { get; set; } = "bi bi-award";

    [Required]
    [StringLength(30)]
    public string ColorClass { get; set; } = "achievement-default";

    [Required]
    [StringLength(300)]
    public string Requirement { get; set; } = string.Empty;

    public ICollection<UserAchievement> UserAchievements { get; set; } = new List<UserAchievement>();
}