using System.ComponentModel.DataAnnotations;

namespace PocketPilot.Models;

public class SavingsGoal : IValidatableObject
{
    public int GoalId { get; set; }

    [Required]
    [StringLength(450)]
    public string UserId { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string GoalName { get; set; } = string.Empty;

    [StringLength(300)]
    public string? Description { get; set; }

    [Range(typeof(decimal), "0.01", "9999999999999999.99")]
    public decimal TargetAmount { get; set; }

    [Range(typeof(decimal), "0", "9999999999999999.99")]
    public decimal CurrentSavedAmount { get; set; }

    [DataType(DataType.Date)]
    public DateTime TargetDate { get; set; }

    [Required]
    [StringLength(20)]
    [RegularExpression("^(Low|Medium|High)$")]
    public string Priority { get; set; } = "Medium";

    [Required]
    [StringLength(20)]
    [RegularExpression("^(Active|Completed|Paused|Cancelled)$")]
    public string Status { get; set; } = "Active";

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public ApplicationUser User { get; set; } = null!;
    public ICollection<SavingsContribution> Contributions { get; set; } = new List<SavingsContribution>();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (CurrentSavedAmount > TargetAmount)
        {
            yield return new ValidationResult(
                "The saved amount cannot exceed the savings goal target.",
                new[] { nameof(CurrentSavedAmount), nameof(TargetAmount) });
        }
    }
}