Place PocketPilot static image assets in this directory.
