﻿(() => {
  "use strict";

  // Close the mobile navigation after choosing an in-page section.
  document.querySelectorAll('#mainNavigation a[href^="/#"]').forEach((link) => {
    link.addEventListener("click", () => {
      const navigation = document.getElementById("mainNavigation");
      if (navigation && window.bootstrap) {
        window.bootstrap.Collapse.getOrCreateInstance(navigation).hide();
      }
    });
  });
})();
