# PocketPilot – Solo College Project

**Tagline:** Your money. Your month. Your plan.

## What this version demonstrates

PocketPilot is intentionally scoped for a solo college project. The core demonstration flow is:

1. Register / Login / Logout
2. Create and manage a monthly budget
3. Add, edit, search, filter, sort, and delete expenses
4. Review the signed-in dashboard and budget spending

## Technology

- ASP.NET Core MVC
- C#
- .NET 6
- Razor Views
- Entity Framework Core 6
- SQL Server Express LocalDB
- ASP.NET Core Identity
- Bootstrap 5
- JavaScript
- LINQ

## Run

The easiest Windows path is:

1. Install Visual Studio 2022 with **ASP.NET and web development**.
2. Ensure the **.NET 6 SDK** and **SQL Server Express LocalDB** are installed.
3. Extract the ZIP so `PocketPilot.sln` is visible in the extracted folder.
4. Double-click `RUN_POCKETPILOT.bat`.

The script restores packages, builds the app, applies EF Core migrations, and launches the `PocketPilot` project.

You can also open `PocketPilot.sln` in Visual Studio 2022 and run the `PocketPilot` project.

## Database

The connection string uses:

`(localdb)\\MSSQLLocalDB`

Database name:

`PocketPilotDb`

Migrations are stored in `PocketPilot/Migrations`.

## Demo accounts

Development-only accounts are seeded when the application runs in the Development environment:

- Admin: `admin@pocketpilot.local` / `PocketPilotAdminDev!2026`
- Student: `student@pocketpilot.local` / `PocketPilotStudentDev!2026`

Do not reuse these credentials outside a local demo database.

## Data ownership

Budgets and expenses are always queried with the authenticated user's Identity ID. Details/edit/delete actions will not return records owned by another user.

## Testing

The `Tests/PocketPilot.Tests` project contains unit tests for the main validation and budget/expense view-model rules. It is kept in the repository but is intentionally not part of the default solution build, so opening `PocketPilot.sln` remains focused on the runnable web application.
