# PocketPilot - Student Budget Survival App

A simple solo college project built with ASP.NET Core MVC, C#, Entity Framework Core, SQL Server LocalDB, Razor, Bootstrap and ASP.NET Core Identity.

## Core features

- User registration and login
- Monthly budget creation and management
- Expense tracking with search/filter/sort
- Signed-in dashboard with current-month budget access

## Run in one go

Double-click `RUN_POCKETPILOT.bat`.

It restores packages, applies EF Core migrations, and starts the app.

Or open `PocketPilot.sln` in Visual Studio 2022 and run the `PocketPilot` project.

## Requirements

- Windows
- Visual Studio 2022 with ASP.NET and web development workload
- .NET 6 SDK
- SQL Server Express LocalDB
- Internet access for the first NuGet restore

## Development credentials

Admin: `admin@pocketpilot.local` / `PocketPilotAdminDev!2026`

Student: `student@pocketpilot.local` / `PocketPilotStudentDev!2026`

These are development-only credentials.

## Scope

This is intentionally a compact solo college project. The main demonstration flow is:

Register/Login -> Dashboard -> Create monthly budget -> Add and manage expenses -> Review budget spending.

Other data models retained from the larger PocketPilot specification are not exposed as completed UI modules in this solo version.

## Fresh-PC checklist

If the one-click script stops, read the first `ERROR:` message in the terminal. The two required machine components are the .NET 6 SDK and SQL Server Express LocalDB. Visual Studio 2022 can install both through the ASP.NET and web development workload.


Expense statement download: open Expenses while logged in and select "Download statement (CSV)". The downloaded CSV includes all expenses belonging to the current account and can be opened in Excel.
