$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

Write-Host 'PocketPilot startup' -ForegroundColor Green

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw '.NET SDK not found. Install the .NET 6 SDK / ASP.NET Core workload in Visual Studio Installer.'
}

if (-not ((dotnet --list-sdks) -match '^6\.')) {
    throw '.NET 6 SDK is required. Install it from Visual Studio Installer.'
}

if (-not (Get-Command sqllocaldb -ErrorAction SilentlyContinue)) {
    throw 'SQL Server Express LocalDB not found. Install the LocalDB component from Visual Studio Installer.'
}

& sqllocaldb info MSSQLLocalDB *> $null
if ($LASTEXITCODE -ne 0) {
    & sqllocaldb create MSSQLLocalDB
}
& sqllocaldb start MSSQLLocalDB *> $null

& dotnet tool restore
& dotnet restore '.\PocketPilot\PocketPilot.csproj'
& dotnet build '.\PocketPilot\PocketPilot.csproj' --no-restore
& dotnet ef database update --project '.\PocketPilot\PocketPilot.csproj' --startup-project '.\PocketPilot\PocketPilot.csproj'
& dotnet run --project '.\PocketPilot\PocketPilot.csproj' --launch-profile PocketPilot
