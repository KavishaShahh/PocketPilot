@echo off
setlocal EnableExtensions
cd /d "%~dp0"

color 0A
title PocketPilot - Setup and Run

echo ================================================
echo             POCKETPILOT STARTUP
echo ================================================
echo.

where dotnet >nul 2>&1
if errorlevel 1 (
  echo ERROR: .NET SDK was not found.
  echo Install the .NET 6 SDK / ASP.NET Core workload in Visual Studio Installer.
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('dotnet --version') do set DOTNET_VERSION=%%v
echo .NET SDK: %DOTNET_VERSION%

dotnet --list-sdks | findstr /r "^6\." >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: A .NET 6 SDK is required by this project.
  echo Install the .NET 6 SDK using Visual Studio Installer, then run this file again.
  pause
  exit /b 1
)

echo Checking SQL Server LocalDB...
where sqllocaldb >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: SQL Server Express LocalDB was not found.
  echo Install the LocalDB component from Visual Studio Installer.
  pause
  exit /b 1
)

sqllocaldb info MSSQLLocalDB >nul 2>&1
if errorlevel 1 (
  echo LocalDB instance MSSQLLocalDB was not found. Creating it...
  sqllocaldb create MSSQLLocalDB
  if errorlevel 1 (
    echo ERROR: Could not create MSSQLLocalDB.
    pause
    exit /b 1
  )
)

sqllocaldb start MSSQLLocalDB >nul 2>&1

echo.
echo Restoring EF Core command-line tools...
dotnet tool restore
if errorlevel 1 (
  echo ERROR: Could not restore the EF Core tool.
  echo Check your internet connection and NuGet access.
  pause
  exit /b 1
)

echo.
echo Restoring NuGet packages...
dotnet restore ".\PocketPilot\PocketPilot.csproj"
if errorlevel 1 (
  echo ERROR: Package restore failed.
  pause
  exit /b 1
)

echo.
echo Building PocketPilot...
dotnet build ".\PocketPilot\PocketPilot.csproj" --no-restore
if errorlevel 1 (
  echo ERROR: The project could not be built.
  echo The messages above show the exact compiler error.
  pause
  exit /b 1
)

echo.
echo Applying database migrations...
dotnet ef database update --project ".\PocketPilot\PocketPilot.csproj" --startup-project ".\PocketPilot\PocketPilot.csproj"
if errorlevel 1 (
  echo ERROR: Database migration failed.
  echo See the messages above for the exact reason.
  pause
  exit /b 1
)

echo.
echo Starting PocketPilot...
echo The browser should open automatically.
echo Press Ctrl+C in this window to stop the app.
echo.

dotnet run --project ".\PocketPilot\PocketPilot.csproj" --launch-profile PocketPilot

pause
