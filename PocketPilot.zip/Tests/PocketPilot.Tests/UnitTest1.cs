using System.ComponentModel.DataAnnotations;
using PocketPilot.ViewModels;

namespace PocketPilot.Tests;

public class BudgetViewModelTests
{
    [Fact]
    public void Validate_RejectsAllocationsAboveTotal()
    {
        var model = ValidBudget();
        model.TotalBudget = 100m;
        model.FoodBudget = 80m;
        model.TravelBudget = 30m;

        var results = Validate(model);

        Assert.Contains(results, result => result.ErrorMessage == "Category allocations cannot exceed your total monthly budget.");
    }

    [Fact]
    public void Validate_RejectsNegativeCategoryAmounts()
    {
        var model = ValidBudget();
        model.TotalBudget = 100m;
        model.FoodBudget = -1m;

        var results = Validate(model);

        Assert.Contains(results, result => result.ErrorMessage == "Category budgets cannot be negative.");
    }

    [Fact]
    public void Validate_RejectsNegativeTotalBudget()
    {
        var model = ValidBudget();
        model.TotalBudget = -1m;

        var results = Validate(model);

        Assert.Contains(results, result => result.MemberNames.Contains(nameof(BudgetViewModel.TotalBudget)));
    }

    [Fact]
    public void Validate_RejectsInvalidMonth()
    {
        var model = ValidBudget();
        model.BudgetMonth = 13;

        Assert.Contains(Validate(model), result => result.MemberNames.Contains(nameof(BudgetViewModel.BudgetMonth)));
    }

    [Fact]
    public void Metrics_HandleOverspendingWithoutClampingMoney()
    {
        var model = ValidBudget();
        model.TotalBudget = 100m;
        model.FoodBudget = 60m;
        model.SpentAmount = 125m;

        Assert.Equal(60m, model.AllocatedBudget);
        Assert.Equal(40m, model.UnallocatedBudget);
        Assert.Equal(-25m, model.RemainingBudget);
        Assert.Equal(125m, model.PercentageSpent);
        Assert.Equal(-25m, model.PercentageRemaining);
    }

    [Fact]
    public void Metrics_ReturnZeroPercentagesForZeroBudget()
    {
        var model = ValidBudget();
        model.TotalBudget = 0m;
        model.SpentAmount = 12m;

        Assert.Equal(0m, model.PercentageSpent);
        Assert.Equal(0m, model.PercentageRemaining);
        Assert.Equal(-12m, model.RemainingBudget);
    }

    [Fact]
    public void CurrencySymbol_UsesConfiguredCurrency()
    {
        var model = ValidBudget();

        model.CurrencyCode = "INR";
        Assert.Equal("₹", model.CurrencySymbol);

        model.CurrencyCode = "EUR";
        Assert.Equal("€", model.CurrencySymbol);
    }

    private static BudgetViewModel ValidBudget() => new()
    {
        BudgetMonth = 10,
        BudgetYear = 2026,
        TotalBudget = 0m
    };

    private static List<ValidationResult> Validate(BudgetViewModel model)
    {
        var results = new List<ValidationResult>();
        Validator.TryValidateObject(model, new ValidationContext(model), results, validateAllProperties: true);
        return results;

    }
}