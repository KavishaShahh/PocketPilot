using System.ComponentModel.DataAnnotations;
using PocketPilot.ViewModels;

namespace PocketPilot.Tests;

public sealed class ExpenseViewModelTests
{
    [Theory]
    [InlineData(0)]
    [InlineData(-2)]
    public void ExpenseViewModel_RejectsZeroOrNegativeAmount(decimal amount)
    {
        var model = ValidExpense();
        model.Amount = amount;

        Assert.Contains(Validate(model), result => result.MemberNames.Contains(nameof(ExpenseViewModel.Amount)));
    }

    [Fact]
    public void ExpenseViewModel_RejectsMissingCategory()
    {
        var model = ValidExpense();
        model.CategoryId = null;

        Assert.Contains(Validate(model), result => result.ErrorMessage == "Please select an expense category.");
    }

    [Fact]
    public void ExpenseViewModel_RejectsOverlongDescription()
    {
        var model = ValidExpense();
        model.Description = new string('x', 101);

        Assert.Contains(Validate(model), result => result.MemberNames.Contains(nameof(ExpenseViewModel.Description)));
    }

    [Fact]
    public void ExpenseViewModel_RejectsUnsupportedPaymentMethod()
    {
        var model = ValidExpense();
        model.PaymentMethod = "Cryptocurrency";

        Assert.Contains(Validate(model), result => result.MemberNames.Contains(nameof(ExpenseViewModel.PaymentMethod)));
    }

    [Fact]
    public void ExpenseViewModel_RejectsUninitializedExpenseDate()
    {
        var model = ValidExpense();
        model.ExpenseDate = default;

        Assert.Contains(Validate(model), result => result.ErrorMessage == "Please choose a valid expense date.");
    }

    [Fact]
    public void ExpenseListViewModel_RejectsDateRangeInReverseOrder()
    {
        var model = new ExpenseListViewModel
        {
            FromDate = new DateTime(2026, 10, 10),
            ToDate = new DateTime(2026, 10, 1)
        };

        Assert.Contains(Validate(model), result => result.ErrorMessage == "The start date must be on or before the end date.");
    }

    private static ExpenseViewModel ValidExpense() => new()
    {
        Amount = 12.50m,
        CategoryId = 1,
        Description = "Lunch",
        ExpenseDate = new DateTime(2026, 10, 5),
        PaymentMethod = "Cash"
    };

    private static List<ValidationResult> Validate(object model)
    {
        var results = new List<ValidationResult>();
        Validator.TryValidateObject(model, new ValidationContext(model), results, validateAllProperties: true);
        return results;
    }
}